﻿using Microsoft.AspNetCore.Mvc;
using MVC.Models;
using MVC.Services.ApiService;

namespace MVC.Controllers
{
    public class FormController : Controller
    {
        private readonly FormApiService _api;

        public FormController(FormApiService api)
        {
            _api = api;
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(FormViewModel model)
        {
            if (!ModelState.IsValid)
                return View(model);

            await _api.SubmitFormAsync(model);
            TempData["Msg"] = "Form Submitted Successfully";
            return RedirectToAction("List");
        }

        // LIST
        public async Task<IActionResult> List()
        {
            var data = await _api.GetAllAsync();
            return View(data);
        }

        // VIEW DETAILS
        public async Task<IActionResult> View(int id)
        {
            var model = await _api.GetByIdAsync(id);
            model.Skills = model.Skills ?? new List<string>();
            return View(model);
        }

        // EDIT GET
        public async Task<IActionResult> Edit(int id)
        {
            var model = await _api.GetByIdAsync(id);
            Console.WriteLine(model.FirstName);
            Console.WriteLine(model.MiddleName);
            Console.WriteLine(model.LastName);
            model.Skills ??= new List<string>();
            return View(model);
        }

        // EDIT POST
        [HttpPost]
        public async Task<IActionResult> Edit(FormViewModel model)
        {
            if (!ModelState.IsValid)
                return View(model);

            // Hidden fields in Edit.cshtml will carry old paths forward
            // If new files are uploaded, they are bound to model.ImageFile, etc.
            // FormApiService.UpdateAsync handles sending them to the API

            await _api.UpdateAsync(model);

            TempData["Msg"] = "Data Updated Successfully";
            return RedirectToAction("List");
        }

        // DELETE
        public async Task<IActionResult> Delete(int id)
        {
            var response = await _api.DeleteAsync(id);

            TempData["Msg"] = response.IsSuccessStatusCode
                ? "Deleted successfully"
                : "Delete failed";

            return RedirectToAction("List");
        }

        // DELETE ALL
        public async Task<IActionResult> DeleteAll()
        {
            var response = await _api.DeleteAllAsync();

            TempData["Msg"] = response.IsSuccessStatusCode
                ? "All data deleted successfully"
                : "Failed to delete all data";

            return RedirectToAction("List");
        }
    }
}
