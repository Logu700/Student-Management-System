﻿using Microsoft.AspNetCore.Http;
using System.Net.Http.Headers;
using MVC.Models;

namespace MVC.Services.ApiService
{
    public class FormApiService
    {
        private readonly HttpClient _client;

        public FormApiService(HttpClient client)
        {
            _client = client;
        }

        // CREATE
        public async Task SubmitFormAsync(FormViewModel model)
        {
            using var content = new MultipartFormDataContent();

            content.Add(new StringContent(model.FirstName), "FirstName");
            content.Add(new StringContent(model.MiddleName ?? ""), "MiddleName");
            content.Add(new StringContent(model.LastName ?? ""), "LastName");
            content.Add(new StringContent(model.Dob.ToString("yyyy-MM-dd")), "DOB");
            content.Add(new StringContent(model.Gender ?? ""), "Gender");
            content.Add(new StringContent(model.ColorHex ?? ""), "ColorHex");

            if (model.Skills != null)
            {
                foreach (var skill in model.Skills)
                    content.Add(new StringContent(skill), "Skills");
            }

            content.Add(new StringContent(model.Country ?? ""), "Country");
            content.Add(new StringContent(model.State ?? ""), "State");
            content.Add(new StringContent(model.District ?? ""), "District");
            content.Add(new StringContent(model.CountryCode ?? ""), "CountryCode");
            content.Add(new StringContent(model.MobileNumber ?? ""), "MobileNumber");

            if (model.ImageFile != null)
                content.Add(new StreamContent(model.ImageFile.OpenReadStream()), "Image", model.ImageFile.FileName);

            if (model.AudioFile != null)
                content.Add(new StreamContent(model.AudioFile.OpenReadStream()), "Audio", model.AudioFile.FileName);

            if (model.VideoFile != null)
                content.Add(new StreamContent(model.VideoFile.OpenReadStream()), "Video", model.VideoFile.FileName);

            if (model.ResumeFile != null)
                content.Add(new StreamContent(model.ResumeFile.OpenReadStream()), "Resume", model.ResumeFile.FileName);

            await _client.PostAsync("api/form", content);
        }

        // GET ALL
        public async Task<List<FormViewModel>> GetAllAsync()
        {
            var response = await _client.GetFromJsonAsync<List<FormViewModel>>("api/form");
            return response ?? new List<FormViewModel>();
        }

        // GET BY ID
        public async Task<FormViewModel?> GetByIdAsync(int id)
        {
            return await _client.GetFromJsonAsync<FormViewModel>($"api/form/{id}");
        }

        // UPDATE
        public async Task UpdateAsync(FormViewModel model)
        {
            using var content = new MultipartFormDataContent();

            content.Add(new StringContent(model.FirstName), "FirstName");
            content.Add(new StringContent(model.MiddleName ?? ""), "MiddleName");
            content.Add(new StringContent(model.LastName ?? ""), "LastName");
            content.Add(new StringContent(model.Dob.ToString("yyyy-MM-dd")), "DOB");
            content.Add(new StringContent(model.Gender ?? ""), "Gender");
            content.Add(new StringContent(model.ColorHex ?? ""), "ColorHex");

            if (model.Skills != null)
            {
                foreach (var skill in model.Skills)
                    content.Add(new StringContent(skill), "Skills");
            }

            content.Add(new StringContent(model.Country ?? ""), "Country");
            content.Add(new StringContent(model.State ?? ""), "State");
            content.Add(new StringContent(model.District ?? ""), "District");
            content.Add(new StringContent(model.CountryCode ?? ""), "CountryCode");
            content.Add(new StringContent(model.MobileNumber ?? ""), "MobileNumber");

            if (model.ImageFile != null)
                content.Add(new StreamContent(model.ImageFile.OpenReadStream()), "Image", model.ImageFile.FileName);

            if (model.AudioFile != null)
                content.Add(new StreamContent(model.AudioFile.OpenReadStream()), "Audio", model.AudioFile.FileName);

            if (model.VideoFile != null)
                content.Add(new StreamContent(model.VideoFile.OpenReadStream()), "Video", model.VideoFile.FileName);

            if (model.ResumeFile != null)
                content.Add(new StreamContent(model.ResumeFile.OpenReadStream()), "Resume", model.ResumeFile.FileName);

            var response = await _client.PutAsync($"api/form/{model.Id}", content);
            response.EnsureSuccessStatusCode();
        }

        // DELETE
        public async Task<HttpResponseMessage> DeleteAsync(int id)
        {
            return await _client.DeleteAsync($"api/form/{id}");
        }

        // DELETE ALL
        public async Task<HttpResponseMessage> DeleteAllAsync()
        {
            return await _client.DeleteAsync("api/form/deleteall");
        }

        public async Task<string> UploadFileAsync(IFormFile file)
        {
            if (file == null || file.Length == 0)
                return null;

            using var content = new MultipartFormDataContent();
            using var stream = file.OpenReadStream();
            var fileContent = new StreamContent(stream);
            fileContent.Headers.ContentType = new MediaTypeHeaderValue(file.ContentType);
            content.Add(fileContent, "file", file.FileName);

            var response = await _client.PostAsync("api/upload", content);
            response.EnsureSuccessStatusCode();
            var path = await response.Content.ReadAsStringAsync();
            return path;
        }
    }
}
