﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MVC.Models
{
    public class FormViewModel
    {
        public int Id { get; set; }
        public string? RegId { get; set; }

        // ===== Name Inputs (MUST be mapped) =====
        [Required(ErrorMessage = "First name is required")]
        [RegularExpression(@"^[A-Z]{1,50}$", ErrorMessage = "First name must contain only CAPITAL letters")]
        public string? FirstName { get; set; }

        [RegularExpression(@"^[A-Z]{0,50}$", ErrorMessage = "Middle name must contain only CAPITAL letters")]
        public string? MiddleName { get; set; }

        [Required(ErrorMessage = "Last name is required")]
        [RegularExpression(@"^[A-Z]{1,50}$", ErrorMessage = "Last name must contain only CAPITAL letters")]
        public string? LastName { get; set; }

        public string? FullName { get; set; }

        // ===== DOB =====
        [Required(ErrorMessage = "Date of Birth is required")]
        [DataType(DataType.Date)]
        public DateTime Dob { get; set; }
        public int Age { get; set; }

        // ===== Gender =====
        [Required(ErrorMessage = "Select gender")]
        public string? Gender { get; set; }

        // ===== Color =====
        [Required(ErrorMessage = "Color selection required")]
        [RegularExpression(@"^#([A-Fa-f0-9]{6})$", ErrorMessage = "Invalid Hex code")]
        public string? ColorHex { get; set; }

        // ===== Skills =====
        [NotMapped]
        [Required(ErrorMessage = "Select at least one skill")]
        public List<string> Skills { get; set; }

        // ===== Location & Mobile =====
        [Required]
        public string? Country { get; set; }

        [Required]
        public string? State { get; set; }

        [Required]
        public string? District { get; set; }

        [NotMapped]
        public string? CountryCode { get; set; }

        [Required]
        [RegularExpression(@"^\d{6,15}$")]
        public string? MobileNumber { get; set; }

        // ===== Files =====
        [NotMapped] public IFormFile ImageFile { get; set; }
        [NotMapped] public IFormFile AudioFile { get; set; }
        [NotMapped] public IFormFile VideoFile { get; set; }
        [NotMapped] public IFormFile ResumeFile { get; set; }

        // Stored paths (GET / display)
        public string? ImagePath { get; set; }
        public string? AudioPath { get; set; }
        public string? VideoPath { get; set; }
        public string? ResumePath { get; set; }
        public DateTime SubmittedAt { get; set; }
    }
}
