﻿namespace API.Models
{
    public class FormResponse
    {
        public int Id { get; set; }
        public string RegId { get; set; }

        public string? FirstName { get; set; }
        public string? MiddleName { get; set; }
        public string? LastName { get; set; }

        public string? FullName { get; set; }
        public DateTime DOB { get; set; }
        public int Age { get; set; }
        public string? Gender { get; set; }
        public string? ColorHex { get; set; }

        // 👇 Client-friendly type
        public List<string> Skills { get; set; } = new();

        public string? Country { get; set; }
        public string? State { get; set; }
        public string? District { get; set; }
        public string? CountryCode { get; set; }
        public string? MobileNumber { get; set; }

        public string? ImagePath { get; set; }
        public string? AudioPath { get; set; }
        public string? VideoPath { get; set; }
        public string? ResumePath { get; set; }

        public DateTime SubmittedAt { get; set; }
    }
}
