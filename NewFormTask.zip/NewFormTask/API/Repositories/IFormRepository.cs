﻿using API.Models;

namespace API.Repositories
{
    public interface IFormRepository
    {
        Task AddAsync(FormEntity entity);
        Task<List<FormEntity>> GetAllAsync();
        Task<FormEntity> GetByIdAsync(int id);
        Task UpdateAsync(FormEntity entity);
        Task DeleteAsync(int id);
        Task DeleteAllAsync();
    }
}
