﻿using API.Models;
using API.Models.Data;
using Microsoft.EntityFrameworkCore;

namespace API.Repositories
{
    public class FormRepository : IFormRepository
    {
        private readonly AppDbContext _context;

        public FormRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task AddAsync(FormEntity entity)
        {
            await _context.Forms.AddAsync(entity);
            await _context.SaveChangesAsync();
        }

        public async Task<List<FormEntity>> GetAllAsync()
        {
            return await _context.Forms.ToListAsync();
        }

        public async Task<FormEntity?> GetByIdAsync(int id)
        {
            return await _context.Forms.FirstOrDefaultAsync(x => x.Id == id);
        }

        public async Task UpdateAsync(FormEntity entity)
        {
            _context.Forms.Update(entity);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var existing = await GetByIdAsync(id);
            if (existing != null)
            {
                _context.Forms.Remove(existing);
                await _context.SaveChangesAsync();

                // 🔥 Reset identity ONLY if table is empty (DEV only)
                if (!await _context.Forms.AnyAsync())
                {
                    await _context.Database.ExecuteSqlRawAsync(
                        "DBCC CHECKIDENT ('Forms', RESEED, 0)");
                }
            }
        }

        public async Task DeleteAllAsync()
        {
            var AllData = await GetAllAsync();
            if (AllData != null)
            {
                _context.Forms.RemoveRange(AllData);
                await _context.SaveChangesAsync();

                await _context.Database.ExecuteSqlRawAsync(
            "DBCC CHECKIDENT ('Forms', RESEED, 0)");
            }
        }
    }
}
