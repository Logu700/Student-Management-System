﻿using API.Models;
using API.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FormController : ControllerBase
    {
        private readonly IFormRepository _repo;
        private readonly IWebHostEnvironment _env;

        public FormController(IFormRepository repo, IWebHostEnvironment env)
        {
            _repo = repo;
            _env = env;
        }

        [HttpPost]
        [Consumes("multipart/form-data")]
        public async Task<IActionResult> Create([FromForm] FormRequest request)
        {

            // Full name
            string fullName =
                $"{request.FirstName} {request.MiddleName} {request.LastName}".Trim();

            // Age calculation
            var today = DateTime.Today;
            int age = today.Year - request.DOB.Year;
            if (request.DOB > today.AddYears(-age)) age--;

            var entity = new FormEntity
            {
                FirstName = request.FirstName,
                MiddleName = request.MiddleName,
                LastName = request.LastName,
                FullName = fullName,
                DOB = request.DOB,
                Age = age,
                Gender = request.Gender,
                ColorHex = request.ColorHex,
                Skills = string.Join(",", request.Skills ?? new List<string>()),
                Country = request.Country,
                State = request.State,
                District = request.District,
                CountryCode = request.CountryCode,
                MobileNumber = request.MobileNumber,
                ImagePath = await SaveFile(request.Image, "Images"),
                AudioPath = await SaveFile(request.Audio, "Audio"),
                VideoPath = await SaveFile(request.Video, "Video"),
                ResumePath = await SaveFile(request.Resume, "Resume"),
                SubmittedAt = DateTime.Now
            };

            await _repo.AddAsync(entity);
            // Generate RegId using Id
            entity.RegId = $"RE{entity.Id:D3}";

            // Update entity with RegId
            await _repo.UpdateAsync(entity);
            return Ok("Form Submitted Successfully");
        }


        [HttpGet]
        public async Task<ActionResult<List<FormResponse>>> GetAll()
        {
            var entities = await _repo.GetAllAsync();

            var response = entities.Select(entity => new FormResponse
            {
                Id = entity.Id,
                RegId = entity.RegId,
                FirstName= entity.FirstName,
                MiddleName= entity.MiddleName,
                LastName= entity.LastName,
                FullName = entity.FullName,
                DOB = entity.DOB,
                Age = entity.Age,
                Gender = entity.Gender,
                ColorHex = entity.ColorHex,

                Skills = string.IsNullOrWhiteSpace(entity.Skills)
                    ? new List<string>()
                    : entity.Skills
                        .Split(',', StringSplitOptions.RemoveEmptyEntries)
                        .Select(s => s.Trim())
                        .ToList(),

                Country = entity.Country,
                State = entity.State,
                District = entity.District,
                CountryCode = entity.CountryCode,
                MobileNumber = entity.MobileNumber,
                ImagePath = entity.ImagePath,
                AudioPath = entity.AudioPath,
                VideoPath = entity.VideoPath,
                ResumePath = entity.ResumePath,
                SubmittedAt = entity.SubmittedAt
            }).ToList();

            return Ok(response);
        }



        // GET BY ID
        [HttpGet("{id}")]
        public async Task<ActionResult<FormResponse>> GetById(int id)
        {
            var entity = await _repo.GetByIdAsync(id);
            if (entity == null) return NotFound();

            var response = new FormResponse
            {
                Id = entity.Id,
                RegId = entity.RegId,
                FirstName= entity.FirstName,
                MiddleName= entity.MiddleName,
                LastName= entity.LastName,
                FullName = entity.FullName,
                DOB = entity.DOB,
                Age = entity.Age,
                Gender = entity.Gender,
                ColorHex = entity.ColorHex,

                Skills = string.IsNullOrWhiteSpace(entity.Skills)
                    ? new List<string>()
                    : entity.Skills
                        .Split(',', StringSplitOptions.RemoveEmptyEntries)
                        .Select(s => s.Trim())
                        .ToList(),

                Country = entity.Country,
                State = entity.State,
                District = entity.District,
                CountryCode = entity.CountryCode,
                MobileNumber = entity.MobileNumber,
                ImagePath = entity.ImagePath,
                AudioPath = entity.AudioPath,
                VideoPath = entity.VideoPath,
                ResumePath = entity.ResumePath,
                SubmittedAt = entity.SubmittedAt
            };

            return Ok(response);
        }


        // UPDATE
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromForm] FormRequest request)
        {
            var entity = await _repo.GetByIdAsync(id);
            if (entity == null)
                return NotFound();

            // Full name
            string fullName =
                $"{request.FirstName} {request.MiddleName} {request.LastName}".Trim();

            // Age calculation
            var today = DateTime.Today;
            int age = today.Year - request.DOB.Year;
            if (request.DOB > today.AddYears(-age)) age--;

            // 🔹 Update fields
            entity.FullName = fullName;
            entity.DOB = request.DOB;
            entity.Age = age;
            entity.Gender = request.Gender;
            entity.ColorHex = request.ColorHex;
            entity.Skills = string.Join(",", request.Skills ?? new List<string>());
            entity.Country = request.Country;
            entity.State = request.State;
            entity.District = request.District;
            entity.CountryCode = request.CountryCode;
            entity.MobileNumber = request.MobileNumber;

            // 🔹 Update files ONLY if new uploaded
            if (request.Image != null)
                entity.ImagePath = await SaveFile(request.Image, "Images");

            if (request.Audio != null)
                entity.AudioPath = await SaveFile(request.Audio, "Audio");

            if (request.Video != null)
                entity.VideoPath = await SaveFile(request.Video, "Video");

            if (request.Resume != null)
                entity.ResumePath = await SaveFile(request.Resume, "Resume");

            await _repo.UpdateAsync(entity);

            // Generate RegId using Id
            entity.RegId = $"RE{entity.Id:D3}";

            // Update entity with RegId
            await _repo.UpdateAsync(entity);

            return Ok("Updated successfully");
        }



        // DELETE
        [HttpDelete("{id}")]
        [Consumes("application/json")]
        public async Task<IActionResult> Delete(int id)
        {
            var data = await _repo.GetByIdAsync(id);
            await _repo.DeleteAsync(id);
            return Ok("Deleted Successfully");
        }

        // DELETE ALL
        [HttpDelete]

        public async Task<IActionResult> DeleteAll()
        {
            await _repo.DeleteAllAsync();
            return Ok("All Records Deleted Successfully");
        }


        [HttpPost]
        private async Task<string?> SaveFile(IFormFile file, string folder)
        {
            if (file == null || file.Length == 0)
                return null;

            var rootPath = Path.Combine(Directory.GetCurrentDirectory(), "Uploads", folder);
            Directory.CreateDirectory(rootPath);

            // ✅ Get original file name safely
            var originalFileName = Path.GetFileName(file.FileName);

            // ✅ Remove dangerous characters
            originalFileName = originalFileName.Replace(" ", "_");

            var filePath = Path.Combine(rootPath, originalFileName);

            // ✅ Prevent overwrite by appending number
            int count = 1;
            string fileNameOnly = Path.GetFileNameWithoutExtension(originalFileName);
            string extension = Path.GetExtension(originalFileName);

            while (System.IO.File.Exists(filePath))
            {
                originalFileName = $"{fileNameOnly}_{count}{extension}";
                filePath = Path.Combine(rootPath, originalFileName);
                count++;
            }

            using var stream = new FileStream(filePath, FileMode.Create);
            await file.CopyToAsync(stream);

            // ✅ Store readable path in DB
            return $"Uploads/{folder}/{originalFileName}";
        }

        [HttpGet("download")]
        public IActionResult Download(string path)
        {
            if (string.IsNullOrEmpty(path))
                return BadRequest();

            var fullPath = Path.Combine(Directory.GetCurrentDirectory(), path);

            if (!System.IO.File.Exists(fullPath))
                return NotFound();

            var fileName = Path.GetFileName(fullPath);
            var contentType = "application/octet-stream";

            return PhysicalFile(fullPath, contentType, fileName);
        }


    }

    // Request Model
    public class FormRequest
    {
        public string? RegId { get; set; }
        public string? FirstName { get; set; }
        public string? MiddleName { get; set; }
        public string? LastName { get; set; }

        public DateTime DOB { get; set; }
        public string? Gender { get; set; }
        public string? ColorHex { get; set; }

        public List<string>? Skills { get; set; }

        public string? Country { get; set; }
        public string? State { get; set; }
        public string? District { get; set; }
        public string? CountryCode { get; set; }
        public string? MobileNumber { get; set; }

        public IFormFile Image { get; set; }
        public IFormFile Audio { get; set; }
        public IFormFile Video { get; set; }
        public IFormFile Resume { get; set; }
    }
}
